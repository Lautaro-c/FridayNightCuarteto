﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace MyGame
{
    public class Player
    {
        private Image playerImage = Engine.LoadImage("assets/player.png");
        private Animation animation;
        private PlayerController playerControl;
        private Transform transform;
        
        public Transform Transform => transform;
       
        public Player(float positionX, float positionY)
        {
            transform = new Transform(positionX, positionY);
            playerControl = new PlayerController(transform);
            CreateAnimaton();
           
        }

        public void CreateAnimaton()
        {
            List<Image> images = new List<Image>();

            for (int i = 0; i < 11; i++)
            {
                Image image = Engine.LoadImage($"assets/Prota/{i}.gif");
                images.Add(image);
            }


            animation = new Animation("Prota", true, 0.1f, images);
        }

        public void Update()
        {
            playerControl.Update();
            animation.Update();
        }


        public void Render()
        {
            Engine.Draw(animation.CurrentImage, transform.Posicion.x +250 , transform.Posicion.y + 250);
        }
    }
}

// PascalCase  => Clases, métodos
// camelCase   => atributos
